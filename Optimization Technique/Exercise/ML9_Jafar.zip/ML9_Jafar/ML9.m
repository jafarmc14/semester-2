clear all;
% Read the dataset
data = readtable("tae.data.txt");
data = table2array(data);

% there are 3 categories, 1=Low, 2=Medium, 3=High
% this task only uses 2 categories
% delete the lowest category
delete_category = 1;
data(ismember(data(:,6), delete_category),:) = [];

%normalized data
for i=1:5
    data(:, i) = (data(:, i) - mean(data(:, i)))/std(data(:, i));
end

% number of data
num_records = size(data, 1);
% number of feature
num_features = size(data, 2) - 1;

% fix the labels to be 1 (TRUE) or -1 (FALSE)
labels = data(:, end);
labels(labels == 2) = -1;
labels(labels == 3) = 1;
data(:, end) = labels;

%defining the belong group and nobelong group
belong_indices = ismember(data(:, end), 1);
notbelong_indices = ismember(data(:, end), -1);
belong = data(belong_indices, :);
notbelong = data(notbelong_indices, :);

disp(" ");
disp("Example of data: ");
disp("Features: ");
disp(data(2, 1: end - 1));
disp("Label: " + num2str(data(2, end)));

% choosing number of data records from each binary class to create the train set
num_record = 25;

% creating the train data
train_set = [belong(1: num_record, :); notbelong(1: num_record, :)];

% creating the test data
test_set = [belong(num_record + 1: num_record * 2, :); notbelong(num_record + 1: num_record * 2, :)];

% randomizing the train set before dividing for linear and non-linear classifier
train_set = train_set(randperm(size(train_set, 1)), :);

% dividing into two sets
train_set_a = train_set(1: num_record, :);
train_set_b = train_set(num_record + 1: num_record * 2, :);

disp(" ");
disp("Linear classifier via primal method");

% using quadratic programming to solve the soft-margin classifier
bias_term = -10;
bias = bias_term * ones(size(train_set_a, 1), 1);
features = [train_set_a(:, 1: end - 1) bias];
labels = train_set_a(:, end);

% quadratic part
lambda = 1;
weights = num_features + 1;
zeta = size(train_set_a, 1);
num_dec = weights + zeta;
H = zeros(num_dec);
H(1: weights, 1: weights) = lambda/2 * eye(weights);

% linear part
f = 1/zeta * [zeros(weights, 1); ones(zeta, 1)];

% constraints
A = -[[labels .* features eye(zeta)]; [zeros(zeta, weights) eye(zeta)]];
b = -[ones(zeta, 1) zeros(zeta, 1)];

% solving the optimization problem
x = quadprog(H, f, A, b);
w = x(1: weights);

disp(" ");
disp("Optimization problem solved with hyperplane weights: ");
disp(w);

% inference on testing set
test_features = [test_set(:, 1: end - 1) bias_term * ones(size(test_set, 1), 1);];
test_labels = test_set(:, end);
results = test_features * w;

% evaluating accuracy
results(results >= 0) = 1;
results(results < 0) = -1;
results_a = results == test_labels;
test_accuracy_a = sum(results_a, 'all')/size(test_labels, 1) * 100;

disp(" ");
disp("[Linear SVM]Accuracy of testing set: " + num2str(test_accuracy_a) + "%");

% parameters: lambda for soft margins, and sigma for RBF kernel
lambda = 0.005;
sigma = 0.25;

disp(" ");
disp("Solving using the kernel method with lambda = " + num2str(lambda) + " and sigma =  " + num2str(sigma));

% features, labels, and number of records
weights = num_features + 1;
zeta = size(train_set_b, 1);
features = train_set_b(:, 1: end - 1);
labels = train_set_b(:, end);

% using RBF kernel
sqr = sum(features' .^ 2);
K = exp((2 * (features * features') - sqr' * ones(1, zeta) - ones(zeta, 1) * sqr)/(2 * sigma ^ 2));

% label vector included 
% resulting in the quadratic part of the cost function
H = (labels * labels') .* K;

% linear part
f = -ones(zeta, 1);

% equality constraint
Aeq = labels';
beq = zeros(1, 1);

% bounds
lb = zeros(zeta, 1);
ub = 1/(2 * zeta * lambda) * ones(zeta, 1);

% solving the quadratic problem
c = quadprog(H, f, [], [], Aeq, beq, lb, ub);

disp(" ");
disp("Optimization problem solved with resulting decision variables values: ");
disp(c);

% for bias calculation
[~, ind] = max(c);
xj = features(ind, :);
b = exp((2 * features * xj' - sum(xj .^ 2) - sqr')/(2 * sigma ^ 2)) .* labels .* c;
b = sum(b) - labels(ind);

% inference on testing set
test_features = test_set(:, 1: end - 1);
test_labels = test_set(:, end);
num_test = size(test_set, 1);
sqr_t = sum(test_features' .^ 2);
results = exp((2 * test_features * features' - sqr_t' * ones(1, zeta) - ones(num_test, 1) * sqr)/(2 * sigma ^ 2));
results = results .* labels' .* c';
results = sum(results, 2) - b;

% evaluating accuracy
results(results >= 0) = 1;
results(results < 0) = -1;
results_b = results == test_labels;
test_accuracy_b = sum(results_b, 'all')/size(test_labels, 1) * 100;

disp(" ");
disp("[Kernel Method] Accuracy on testing set: " + num2str(test_accuracy_b) + "%");